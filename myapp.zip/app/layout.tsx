
// import type { Metadata } from "next";
import localFont from "next/font/local";
// import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import "lenis/dist/lenis.css";

// Layout components
import Header from "@/layouts/header";
import Footer from "@/layouts/footer"
import SmoothScroll from "@/components/smooth-scroll";



const aileron = localFont({
  src: [
    {
      path: "../assets/font/Aileron-Regular.otf",
      weight: "400",
      style: "normal",
    },
    {
      path: "../assets/font/Aileron-SemiBold.otf",
      weight: "600",
      style: "normal",
    },
    {
      path: "../assets/font/Aileron-Bold.otf",
      weight: "700",
      style: "normal",
    },
    {
      path: "../assets/font/Aileron-Heavy.otf",
      weight: "800",
      style: "normal",
    },
    {
      path: "../assets/font/Aileron-Black.otf",
      weight: "900",
      style: "normal",
    },
  ],
  variable: "--font-aileron",
});




export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
       <html
      lang="en"
      className={`h-full  antialiased`}
    >
      <body className={`min-h-full flex flex-col text-dark-primary ${aileron.variable} `} cz-shortcut-listen="true">
        <SmoothScroll>
          <Header />
          {children}
          <Footer />
        </SmoothScroll>
      </body>
    </html>
  );
}
